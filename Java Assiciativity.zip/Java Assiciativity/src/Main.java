
//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        //int a=6*5-34/2;
        /*
        =30-34/2
        =30-17
        =13
         */
        //precedence we see here
       // System.out.println(a);
       // int b=60/5-35*2;
        /*
        = 12-34*2
        =12-68
        =-56
         */
       // System.out.println(b);
      /* int a,b;
      a=b=45;
        System.out.println(a);
        System.out.println(b);*/
        /* int x=6;
        int y=1;
        int k=x*y/2;
        System.out.println(k);
        //Left to right we see */
        int b=1;
        int c=4;
        int a=5;
        int k;
        k=b*b-(4*a*c)/(2*a);
        System.out.println(k);
    }
}